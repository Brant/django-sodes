"""
Utility features for Sodes module
"""