"""
3rd party packages, localized for use in this module
"""