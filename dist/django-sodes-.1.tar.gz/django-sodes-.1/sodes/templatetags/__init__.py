"""
Template tags and filters for django-sodes
"""