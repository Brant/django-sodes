"""
Django-sodes


Simple podcasting
"""